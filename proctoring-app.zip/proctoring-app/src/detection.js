// ─── Gaze Direction ───────────────────────────────────────────────────────────
// Returns: 'center' | 'left' | 'right' | 'up' | 'down'
export function getGazeDirection(landmarks) {
  if (!landmarks || landmarks.length < 478) return 'center';

  // Left eye landmarks (outer=33, inner=133, top=159, bottom=145)
  // Right eye landmarks (outer=362, inner=263, top=386, bottom=374)
  // Iris: left center=468, right center=473
  const leftIris = landmarks[468];
  const rightIris = landmarks[473];
  const leftOuter = landmarks[33];
  const leftInner = landmarks[133];
  const leftTop = landmarks[159];
  const leftBottom = landmarks[145];
  const rightOuter = landmarks[362];
  const rightInner = landmarks[263];
  const rightTop = landmarks[386];
  const rightBottom = landmarks[374];

  if (!leftIris || !rightIris) return 'center';

  const leftEyeWidth = Math.abs(leftInner.x - leftOuter.x);
  const rightEyeWidth = Math.abs(rightInner.x - rightOuter.x);
  const leftEyeHeight = Math.abs(leftBottom.y - leftTop.y);
  const rightEyeHeight = Math.abs(rightBottom.y - rightTop.y);

  if (leftEyeWidth < 0.001 || rightEyeWidth < 0.001) return 'center';

  const leftHRatio = (leftIris.x - leftOuter.x) / leftEyeWidth;
  const rightHRatio = (rightIris.x - rightOuter.x) / rightEyeWidth;
  const avgHRatio = (leftHRatio + rightHRatio) / 2;

  const leftVRatio = leftEyeHeight > 0.001
    ? (leftIris.y - leftTop.y) / leftEyeHeight : 0.5;
  const rightVRatio = rightEyeHeight > 0.001
    ? (rightIris.y - rightTop.y) / rightEyeHeight : 0.5;
  const avgVRatio = (leftVRatio + rightVRatio) / 2;

  if (avgHRatio < 0.36) return 'left';
  if (avgHRatio > 0.64) return 'right';
  if (avgVRatio < 0.28) return 'up';
  if (avgVRatio > 0.72) return 'down';
  return 'center';
}

// ─── Head Pose ────────────────────────────────────────────────────────────────
// Returns: 'center' | 'left' | 'right' | 'up' | 'down'
export function getHeadDirection(landmarks) {
  if (!landmarks || landmarks.length < 468) return 'center';

  const noseTip = landmarks[1];
  const leftFace = landmarks[127];
  const rightFace = landmarks[356];
  const forehead = landmarks[10];
  const chin = landmarks[152];

  if (!noseTip || !leftFace || !rightFace || !forehead || !chin) return 'center';

  const faceWidth = Math.abs(rightFace.x - leftFace.x);
  const faceHeight = Math.abs(chin.y - forehead.y);
  if (faceWidth < 0.001 || faceHeight < 0.001) return 'center';

  const faceCenterX = (leftFace.x + rightFace.x) / 2;
  const faceCenterY = (forehead.y + chin.y) / 2;

  const yawRatio = (noseTip.x - faceCenterX) / faceWidth;
  const pitchRatio = (noseTip.y - faceCenterY) / faceHeight;

  if (yawRatio > 0.07) return 'right';
  if (yawRatio < -0.07) return 'left';
  if (pitchRatio < -0.06) return 'up';
  if (pitchRatio > 0.08) return 'down';
  return 'center';
}

// ─── Canvas Overlay ───────────────────────────────────────────────────────────
export function drawOverlays(canvas, video, landmarks, headDir, suspiciousObjects) {
  const ctx = canvas.getContext('2d');
  const w = canvas.width;
  const h = canvas.height;

  ctx.clearRect(0, 0, w, h);

  if (!landmarks || landmarks.length < 478) {
    // No face — draw scan lines
    ctx.strokeStyle = 'rgba(255, 50, 50, 0.15)';
    ctx.lineWidth = 1;
    for (let y = 0; y < h; y += 8) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }
    return;
  }

  const toCanvas = (lm) => ({ x: lm.x * w, y: lm.y * h });

  // ── Draw iris points with glow ──
  const leftIris = landmarks[468];
  const rightIris = landmarks[473];

  if (leftIris && rightIris) {
    [leftIris, rightIris].forEach(iris => {
      const p = toCanvas(iris);
      // Outer glow
      const grad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, 10);
      grad.addColorStop(0, 'rgba(0, 255, 136, 0.9)');
      grad.addColorStop(0.5, 'rgba(0, 255, 136, 0.3)');
      grad.addColorStop(1, 'rgba(0, 255, 136, 0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(p.x, p.y, 10, 0, Math.PI * 2);
      ctx.fill();

      // Core dot
      ctx.fillStyle = '#00ff88';
      ctx.beginPath();
      ctx.arc(p.x, p.y, 3, 0, Math.PI * 2);
      ctx.fill();
    });
  }

  // ── Draw nose-to-chin line (head pose indicator) ──
  const noseTip = landmarks[1];
  const chin = landmarks[152];
  if (noseTip && chin) {
    const noseP = toCanvas(noseTip);
    const chinP = toCanvas(chin);
    const isAligned = headDir === 'center';

    ctx.strokeStyle = isAligned ? 'rgba(0, 255, 136, 0.8)' : 'rgba(255, 60, 60, 0.9)';
    ctx.lineWidth = 2;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(noseP.x, noseP.y);
    ctx.lineTo(chinP.x, chinP.y);
    ctx.stroke();
    ctx.setLineDash([]);

    // Direction arrow
    if (!isAligned) {
      ctx.fillStyle = 'rgba(255, 60, 60, 0.9)';
      ctx.font = `bold ${Math.round(w * 0.04)}px IBM Plex Mono`;
      ctx.textAlign = 'center';
      const arrowMap = { left: '◀', right: '▶', up: '▲', down: '▼' };
      const midX = (noseP.x + chinP.x) / 2;
      const midY = (noseP.y + chinP.y) / 2;
      ctx.fillText(arrowMap[headDir] || '', midX, midY);
    }
  }

  // ── Draw suspicious object bounding boxes ──
  if (suspiciousObjects && suspiciousObjects.length > 0) {
    const labelMap = {
      'cell phone': 'โทรศัพท์',
      'book': 'หนังสือ',
      'laptop': 'แล็ปท็อป',
      'remote': 'รีโมต',
      'tablet': 'แท็บเล็ต',
    };

    suspiciousObjects.forEach(obj => {
      const [x, y, bw, bh] = obj.bbox;
      ctx.strokeStyle = 'rgba(255, 50, 50, 0.9)';
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y, bw, bh);

      // Corners
      const cs = 12;
      ctx.strokeStyle = '#ff3232';
      ctx.lineWidth = 3;
      [[x, y], [x + bw, y], [x, y + bh], [x + bw, y + bh]].forEach(([cx, cy]) => {
        ctx.beginPath();
        ctx.moveTo(cx - cs * Math.sign(bw / 2 - (cx - x)), cy);
        ctx.lineTo(cx, cy);
        ctx.lineTo(cx, cy - cs * Math.sign(bh / 2 - (cy - y)));
        ctx.stroke();
      });

      // Label badge
      const label = labelMap[obj.class] || obj.class;
      const pct = Math.round(obj.score * 100);
      const text = `${label} ${pct}%`;
      ctx.font = `bold ${Math.round(w * 0.025)}px IBM Plex Mono`;
      const tw = ctx.measureText(text).width;
      ctx.fillStyle = 'rgba(255, 30, 30, 0.85)';
      ctx.fillRect(x, y - 24, tw + 12, 22);
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'left';
      ctx.fillText(text, x + 6, y - 7);
    });
  }
}
